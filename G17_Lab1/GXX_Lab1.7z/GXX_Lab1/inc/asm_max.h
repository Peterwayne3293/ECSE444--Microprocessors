#ifndef _ASM_MAX
#define _ASM_MAX

	void asm_max(float *f_arr, int N, float *max, int *max_idx);

#endif
