#ifndef _EXAMPLE7_H
#define _EXAMPLE7_H

extern int example7_asm(int a);
int example7_c(int a);

#endif
