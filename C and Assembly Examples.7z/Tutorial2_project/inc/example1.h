#ifndef _EXAMPLE1_H
#define _EXAMPLE1_H

extern int example1_asm(int a, int b);
int example1_c(int a, int b);

#endif
