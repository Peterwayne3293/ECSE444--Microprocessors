#ifndef _EXAMPLE6_H
#define _EXAMPLE6_H

extern void example6_asm(float *a, float *b, int length);
void example6_c(float *a, float *b, int length);

#endif
