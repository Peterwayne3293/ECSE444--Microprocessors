#ifndef _EXAMPLE2_H
#define _EXAMPLE2_H

extern float example2_asm(float a, float b);
float example2_c(float a, float b);

#endif
