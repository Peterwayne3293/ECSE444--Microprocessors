#ifndef _EXAMPLE4_H
#define _EXAMPLE4_H

extern float example4_asm(float a, float b);
float example4_c(float a, float b);

#endif
