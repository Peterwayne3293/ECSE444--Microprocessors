#ifndef _EXAMPLE5_H
#define _EXAMPLE5_H

extern void example5_asm(int *a, int *b, int length);
void example5_c(int *a, int *b, int length);

#endif
