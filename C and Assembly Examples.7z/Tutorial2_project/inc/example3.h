#ifndef _EXAMPLE3_H
#define _EXAMPLE3_H

extern int example3_asm(int a, int b);
int example3_c(int a, int b);

#endif
