#ifndef _EXAMPLE8_H
#define _EXAMPLE8_H

extern int example8_asm(int a);
int example8_c(int a);

#endif
