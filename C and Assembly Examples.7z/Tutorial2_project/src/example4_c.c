#include <example4.h>

float example4_c(float a, float b) {
	
	float retval = a*b;
	return retval;
}
