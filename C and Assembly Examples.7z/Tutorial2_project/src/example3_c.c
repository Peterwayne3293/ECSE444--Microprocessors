#include <example3.h>

int example3_c(int a, int b) {
	
	int retval = a*b;
	return retval;
}
