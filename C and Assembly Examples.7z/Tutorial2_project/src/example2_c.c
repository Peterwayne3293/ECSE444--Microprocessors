#include <example2.h>

float example2_c(float a, float b) {
	
	float retval = a+b;
	return retval;
}
