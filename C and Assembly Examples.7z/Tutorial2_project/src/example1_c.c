#include <example1.h>

int example1_c(int a, int b) {
	
	int retval = a+b;
	return retval;
}
