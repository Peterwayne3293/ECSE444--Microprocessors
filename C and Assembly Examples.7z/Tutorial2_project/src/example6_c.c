#include <example5.h>

void example6_c(float *a, float *b, int length) {
		int i;
	
		for(i=0 ; i<length ; i++)
			b[i] = a[i];
}
